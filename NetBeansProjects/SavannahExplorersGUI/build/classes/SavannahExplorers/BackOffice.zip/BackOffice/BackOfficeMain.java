/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SavannahExplorers.BackOffice;
/**
 *
 * @author rdesibi
 */
import java.io.IOException;
import java.io.File;
import java.io.FileInputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.file.Paths;
import java.util.Properties;
import javax.swing.JFileChooser;
import javax.swing.SwingWorker;
import java.awt.Dimension;
import java.awt.Image;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Desktop;
import java.net.URI;
import java.net.URLEncoder;


public class BackOfficeMain extends javax.swing.JFrame {

    /** Set to true in config.properties (use.api=true) to enable API integration. */
    private static boolean USE_API = false;
    private static final String CONFIG_FILE = "config.properties";
    /** Base URL for the Leads lookup page — overridden from api.base_url in config.properties */
    private static String LEADS_LOOKUP_URL = "https://hub.savannahexplorers.com/modules/leads/lookup.php";
    /** API key loaded from config.properties — used for direct HTTP calls that need a longer timeout */
    private static String API_KEY_VALUE = "";

    /**
     * Creates new form BackOfficeMain
     */
    public BackOfficeMain() {
        initComponents();
        // Fix LUX: JViewport ignores setMaximumSize e forza jPanel1 ad allargarsi.
        // La vera causa sono i 4 JTextField senza vincoli nel GroupLayout che si espandono
        // quando jPanel1 viene allargato, aumentando PAR_C e spingendo LUX a destra.
        // Bloccando preferred+max di questi campi il layout diventa rigido.
        java.awt.Dimension fixedSearch = new java.awt.Dimension(260, 26);
        java.awt.Dimension fixedRename = new java.awt.Dimension(360, 26);
        jTextField8.setPreferredSize(fixedSearch);  jTextField8.setMaximumSize(fixedSearch);
        jTextField9.setPreferredSize(fixedSearch);  jTextField9.setMaximumSize(fixedSearch);
        jTextField6.setPreferredSize(fixedRename);  jTextField6.setMaximumSize(fixedRename);
        jTextField7.setPreferredSize(fixedRename);  jTextField7.setMaximumSize(fixedRename);
        // Set minimum window size (wider for readability)
        setMinimumSize(new java.awt.Dimension(1300, 860));
        setSize(1440, 960);

        // Hide Browse buttons (replaced by Search with results popup)
        jSearch.setVisible(false);
        jSearchSafari.setVisible(false);

        // Hide Exit button (replaced by menu)
        jButton6.setVisible(false);

        // ── Auto-scan Prog Number when Customer Request changes ──────────────
        jTextField1.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            private javax.swing.Timer timer = null;
            private void schedule() {
                if (timer != null) timer.stop();
                // Debounce 400 ms so we don't scan on every keystroke
                timer = new javax.swing.Timer(400, e -> autoScanProgNumber());
                timer.setRepeats(false);
                timer.start();
            }
            public void insertUpdate(javax.swing.event.DocumentEvent e)  { schedule(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e)  { schedule(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) { schedule(); }
        });

        // Add Lookup Leads menu item (opens browser with Customer Request string pre-filled)
        javax.swing.JMenu lookupMenu = new javax.swing.JMenu("Lookup Leads");
        lookupMenu.setFont(new java.awt.Font("SansSerif", java.awt.Font.BOLD, 13));
        lookupMenu.setForeground(new java.awt.Color(0, 100, 180));
        lookupMenu.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override public void mousePressed(java.awt.event.MouseEvent e) {
                lookupLeadsInBrowser();
            }
        });
        jMenuBar1.add(lookupMenu);

        // Add Help menu
        javax.swing.JMenu helpMenu = new javax.swing.JMenu("Help");
        helpMenu.setFont(new java.awt.Font("SansSerif", java.awt.Font.BOLD, 13));
        javax.swing.JMenuItem helpItem = new javax.swing.JMenuItem("User Guide");
        helpItem.addActionListener(e -> showHelpDialog());
        helpMenu.add(helpItem);
        jMenuBar1.add(helpMenu);

        // Add Exit as last item in menu bar (direct click, no dropdown)
        javax.swing.JMenu exitMenu = new javax.swing.JMenu("Exit");
        exitMenu.setFont(new java.awt.Font("SansSerif", java.awt.Font.BOLD, 13));
        exitMenu.setForeground(new java.awt.Color(160, 26, 20));
        exitMenu.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override public void mousePressed(java.awt.event.MouseEvent e) {
                System.exit(0);
            }
        });
        jMenuBar1.add(exitMenu);

        // Fonts handled by buildMainLayout()

        // --- Load config and optionally show login ---
        USE_API = loadConfig();
        if (USE_API) {
            LoginDialog login = new LoginDialog(this, AppSession.api);
            login.setVisible(true);
            if (!login.loginSuccessful) {
                System.exit(0);
            }
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jRadioButtonMenuItem1 = new javax.swing.JRadioButtonMenuItem();
        jMenu3 = new javax.swing.JMenu();
        jScrollPane1 = new javax.swing.JScrollPane();
        jMenuItem3 = new javax.swing.JMenuItem();
        jScrollBar2 = new javax.swing.JScrollBar();
        jScrollPane2 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jCheckBox1 = new javax.swing.JCheckBox();
        jCheckBox2 = new javax.swing.JCheckBox();
        jCheckBox3 = new javax.swing.JCheckBox();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jCheckBox4 = new javax.swing.JCheckBox();
        jCheckBox5 = new javax.swing.JCheckBox();
        jCheckBox6 = new javax.swing.JCheckBox();
        jCheckBox7 = new javax.swing.JCheckBox();
        jCheckBox8 = new javax.swing.JCheckBox();
        jCheckBox11 = new javax.swing.JCheckBox();
        jCheckBox12 = new javax.swing.JCheckBox();
        jCheckBox13 = new javax.swing.JCheckBox();
        jCheckBox16 = new javax.swing.JCheckBox();
        jCheckBox17 = new javax.swing.JCheckBox();
        machame = new javax.swing.JCheckBox();
        jCheckBox19 = new javax.swing.JCheckBox();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jButton11 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jCheckBox22 = new javax.swing.JCheckBox();
        jButton12 = new javax.swing.JButton();
        jCheckBox24 = new javax.swing.JCheckBox();
        jCheckBox25 = new javax.swing.JCheckBox();
        jCheckBox26 = new javax.swing.JCheckBox();
        jCheckBox27 = new javax.swing.JCheckBox();
        jCheckBox28 = new javax.swing.JCheckBox();
        jLabel9 = new javax.swing.JLabel();
        jTextField4 = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JComboBox<>(new String[]{"2026", "001_safari"});
        jTextField5.setEditable(true);
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jButton15 = new javax.swing.JButton();
        jTextField6 = new javax.swing.JTextField();
        jTextField7 = new javax.swing.JTextField();
        jTextField8 = new javax.swing.JTextField();
        jTextField9 = new javax.swing.JTextField();
        jButton17 = new javax.swing.JButton();
        jButton18 = new javax.swing.JButton();
        DumaPemba = new javax.swing.JCheckBox();
        PumbaPemba = new javax.swing.JCheckBox();
        Simba2 = new javax.swing.JCheckBox();
        GranSafari = new javax.swing.JCheckBox();
        machame6 = new javax.swing.JCheckBox();
        jDumaShort = new javax.swing.JCheckBox();
        jButton7 = new javax.swing.JButton();
        BeachDumaShort = new javax.swing.JCheckBox();
        String[] statusValues    = {"PROGRESS","PROVISIONAL","DEPOSIT","BALANCE","BALANCE-CASH","CANCELLED","PAID"};
        String[] statusValuesTo  = {"PROGRESS","PROVISIONAL","DEPOSIT","BALANCE","BALANCE-CASH","CANCELLED","PAID"};
        jComboBoxFrom = new javax.swing.JComboBox<>(statusValues);
        jComboBoxTo   = new javax.swing.JComboBox<>(statusValuesTo);
        jButtonRename = new javax.swing.JButton();
        jSearch = new javax.swing.JButton();
        jSearchSafari = new javax.swing.JButton();
        Lemosho10days = new javax.swing.JCheckBox();
        Marangu7days = new javax.swing.JCheckBox();
        SundayGRP = new javax.swing.JCheckBox();
        Simba3 = new javax.swing.JCheckBox();
        SimbaPemba = new javax.swing.JCheckBox();
        jLabel7 = new javax.swing.JLabel();
        jTextField10 = new javax.swing.JTextField();
        jLabel7b = new javax.swing.JLabel();
        jTextField10b = new javax.swing.JTextField();
        ThursdayGRP = new javax.swing.JCheckBox();
        jLabel14 = new javax.swing.JLabel();
        jLuxDuma = new javax.swing.JCheckBox();
        jLuxPumba = new javax.swing.JCheckBox();
        jLuxSimba = new javax.swing.JCheckBox();
        jDC = new javax.swing.JCheckBox();
        jPC = new javax.swing.JCheckBox();
        jSC = new javax.swing.JCheckBox();
        jKC = new javax.swing.JCheckBox();
        jButton14 = new javax.swing.JButton();
        jTextField11 = new javax.swing.JTextField();
        jButtonClearRename = new javax.swing.JButton();
        jButtonToCustomerFile = new javax.swing.JButton();
        jCheckBox9 = new javax.swing.JCheckBox();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem13 = new javax.swing.JMenuItem();
        jMenuItem16 = new javax.swing.JMenuItem();
        jMenuItem17 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenu4 = new javax.swing.JMenu();
        jMenuItem6 = new javax.swing.JMenuItem();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenu5 = new javax.swing.JMenu();
        jMenuItem4 = new javax.swing.JMenuItem();

        jRadioButtonMenuItem1.setSelected(true);
        jRadioButtonMenuItem1.setText("jRadioButtonMenuItem1");

        jMenu3.setText("jMenu3");

        jMenuItem3.setText("jMenuItem3");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Savannah Explorers Ltd");

        jPanel1.setName(""); // NOI18N

        jLabel1.setText("Customer Request");

        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        jButton1.setText("NEW REQUEST");
        jButton1.setFont(new java.awt.Font("SansSerif", java.awt.Font.BOLD, 13));
        jButton1.setBackground(new java.awt.Color(80, 80, 80));
        jButton1.setForeground(java.awt.Color.WHITE);
        jButton1.setOpaque(true);
        jButton1.setBorderPainted(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Open 2026 Folder");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("Clear");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jCheckBox1.setText("Duma");
        jCheckBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox1ActionPerformed(evt);
            }
        });

        jCheckBox2.setText("Pumba");

        jCheckBox3.setText("Simba");

        jButton4.setText("Copy Programs");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setText("Clear Checkbox");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton6.setText("Exit");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jCheckBox4.setText("Kiboko");
        jCheckBox4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox4ActionPerformed(evt);
            }
        });

        jCheckBox5.setText("Tembo");
        jCheckBox5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox5ActionPerformed(evt);
            }
        });

        jCheckBox6.setText("Chui");

        jCheckBox7.setText("Faru");
        jCheckBox7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox7ActionPerformed(evt);
            }
        });

        jCheckBox8.setText("Mbogo");

        jCheckBox11.setText("MigrationWinter");

        jCheckBox12.setText("MigrationSummer");
        jCheckBox12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox12ActionPerformed(evt);
            }
        });

        jCheckBox13.setText("Ndege");

        jCheckBox16.setText("BeachPumba");
        jCheckBox16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox16ActionPerformed(evt);
            }
        });

        jCheckBox17.setText("BeachKiboko");

        machame.setText("Machame-9 days");
        machame.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                machameActionPerformed(evt);
            }
        });

        jCheckBox19.setText("Marangu-8 days");
        jCheckBox19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox19ActionPerformed(evt);
            }
        });

        jLabel2.setText("*** Safari ***");

        jLabel3.setText("*** Safari+Beach ***");

        jLabel4.setText("*** Trekking ***");

        jButton11.setText("Confirm Safari");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });

        jLabel5.setText("Start Date");

        jTextField2.setText("NA");
        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });

        jLabel6.setText("End Date");

        jTextField3.setText("NA");

        jLabel8.setText("*** Beach ***");

        jCheckBox22.setText("Zanzibar Safari");
        jCheckBox22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox22ActionPerformed(evt);
            }
        });

        jButton12.setText("Status");
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });

        jCheckBox24.setText("BeachSimba");

        jCheckBox25.setText("Rongai-8days");

        jCheckBox26.setText("Lemosho-9 days");
        jCheckBox26.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox26ActionPerformed(evt);
            }
        });

        jCheckBox27.setText("Nyani");
        jCheckBox27.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox27ActionPerformed(evt);
            }
        });

        jCheckBox28.setText("Baobab");
        jCheckBox28.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox28ActionPerformed(evt);
            }
        });

        jLabel9.setText("ProgNumber");

        jTextField4.setText("01");

        jLabel10.setText("Rename in Folder");

        jTextField5.setSelectedItem("2026");

        jLabel11.setText("Current name");

        jLabel12.setText("New name");

        jButton15.setText("Rename");
        jButton15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton15ActionPerformed(evt);
            }
        });

        jButtonClearRename.setText("Clear");
        jButtonClearRename.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonClearRenameActionPerformed(evt);
            }
        });

        jButtonToCustomerFile.setText("Copy To Customer File");
        jButtonToCustomerFile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonToCustomerFileActionPerformed(evt);
            }
        });

        jTextField7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField7ActionPerformed(evt);
            }
        });

        jTextField8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField8ActionPerformed(evt);
            }
        });

        jButton17.setText("Search 2026 Folder");
        jButton17.setToolTipText("");
        jButton17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton17ActionPerformed(evt);
            }
        });

        jButton18.setText("Search 001_Safari Folder");
        jButton18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton18ActionPerformed(evt);
            }
        });

        DumaPemba.setLabel("Duma+Pemba");
        DumaPemba.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DumaPembaActionPerformed(evt);
            }
        });

        PumbaPemba.setText("Pumba+Pemba");
        PumbaPemba.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PumbaPembaActionPerformed(evt);
            }
        });

        Simba2.setText("Simba2");

        GranSafari.setText("GranSafari");

        machame6.setText("Machame-8 days");
        machame6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                machame6ActionPerformed(evt);
            }
        });

        jDumaShort.setText("DumaShort");
        jDumaShort.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jDumaShortActionPerformed(evt);
            }
        });

        jButton7.setText("Open 001_Safari Folder");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        BeachDumaShort.setText("BeachDumaShort");
        BeachDumaShort.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BeachDumaShortActionPerformed(evt);
            }
        });

        jComboBoxFrom.setSelectedIndex(0); // default FROM = PROGRESS
        jComboBoxTo.setSelectedIndex(2);   // default TO   = DEPOSIT

        jButtonRename.setText("Rename");
        jButtonRename.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonRenameActionPerformed(evt);
            }
        });

        jSearch.setText("Browse 2026");
        jSearch.setActionCommand("jSearch");
        jSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jSearchActionPerformed(evt);
            }
        });

        jSearchSafari.setText("Browse 001_Safari");
        jSearchSafari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jSearchSafariActionPerformed(evt);
            }
        });

        Lemosho10days.setText("Lemosho-10 days");

        Marangu7days.setText("Marangu-7 days");
        Marangu7days.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Marangu7daysActionPerformed(evt);
            }
        });

        SundayGRP.setText("Simba-GRP");
        SundayGRP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SundayGRPActionPerformed(evt);
            }
        });

        Simba3.setText("Simba3");
        Simba3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Simba3ActionPerformed(evt);
            }
        });

        SimbaPemba.setText("Simba + Pemba");

        jLabel7.setText("Middle Date");

        jTextField10.setText("NA");
        jTextField10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField10ActionPerformed(evt);
            }
        });

        jLabel7b.setText("Middle Date 2");

        jTextField10b.setText("NA");
        jTextField10b.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField10bActionPerformed(evt);
            }
        });

        ThursdayGRP.setText("Duma-GRP");

        jLabel14.setText("*** LUX & CLASSIC SAFARI ***");

        jLuxDuma.setText("Lux Duma");
        jLuxDuma.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jLuxDumaActionPerformed(evt);
            }
        });

        jLuxPumba.setText("Lux Pumba");

        jLuxSimba.setText("Lux Simba");

        jDC.setText("Duma Classic");
        jDC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jDCActionPerformed(evt);
            }
        });

        jPC.setText("Pumba Classic");

        jSC.setText("Simba Classic");

        jKC.setText("Kiboko Classic");

        jButton14.setText("Search 001_safari including subfolder for:");
        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });

        jCheckBox9.setText("Gombe Katavi");

        buildMainLayout();
        // ── Menu setup ──────────────────────────────────────
        // Folders menu
        jMenu1.setText("Folders");
        jMenuItem13.setText("001_Safari");
        jMenuItem13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) { jMenuItem13ActionPerformed(evt); }
        });
        jMenu1.add(jMenuItem13);
        jMenuItem16.setText("000_Contracts");
        jMenuItem16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) { jMenuItem16ActionPerformed(evt); }
        });
        jMenu1.add(jMenuItem16);
        jMenuItem17.setText("Zanzibar");
        jMenuItem17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) { jMenuItem17ActionPerformed(evt); }
        });
        jMenu1.add(jMenuItem17);
        jMenuItem2.setText("Agenzia");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) { jMenuItem2ActionPerformed(evt); }
        });
        jMenu1.add(jMenuItem2);
        jMenuBar1.add(jMenu1);

        // Groups & CK menu
        jMenu4.setText("Groups & CK");
        jMenu4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) { jMenu4ActionPerformed(evt); }
        });
        jMenuItem6.setText("GRP groups");
        jMenuItem6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) { jMenuItem6ActionPerformed(evt); }
        });
        jMenu4.add(jMenuItem6);
        jMenuItem1.setText("Missing CK");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) { jMenuItem1ActionPerformed(evt); }
        });
        jMenu4.add(jMenuItem1);
        jMenuBar1.add(jMenu4);

        // Bookings menu
        jMenu5.setText("Bookings");
        jMenuItem4.setText("PROGRESS");
        jMenuItem4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) { jMenuItem4ActionPerformed(evt); }
        });
        jMenu5.add(jMenuItem4);
        jMenuBar1.add(jMenu5);

        // Status — standalone clickable menu item after Bookings
        javax.swing.JMenu statusMenu = new javax.swing.JMenu("Status");
        statusMenu.setFont(new java.awt.Font("SansSerif", java.awt.Font.BOLD, 13));
        statusMenu.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override public void mousePressed(java.awt.event.MouseEvent e) {
                jButton12ActionPerformed(null);
            }
        });
        jMenuBar1.add(statusMenu);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // ── Clean replacement for auto-generated GroupLayout ─────────────────────
    private void buildMainLayout() {
        java.awt.Font base = new java.awt.Font("SansSerif", java.awt.Font.PLAIN, 13);
        java.awt.Font bold = new java.awt.Font("SansSerif", java.awt.Font.BOLD, 13);
        java.awt.Font big  = new java.awt.Font("SansSerif", java.awt.Font.BOLD, 15);
        java.awt.Font head = new java.awt.Font("SansSerif", java.awt.Font.BOLD, 12);

        jPanel1.setLayout(new javax.swing.BoxLayout(jPanel1, javax.swing.BoxLayout.Y_AXIS));
        jPanel1.setBorder(javax.swing.BorderFactory.createEmptyBorder(8, 14, 14, 14));
        jPanel1.setBackground(new java.awt.Color(236, 236, 236));

        // ── NEW REQUEST ──────────────────────────────────────────────────────
        jButton1.setFont(big);
        jButton1.setBackground(new java.awt.Color(70, 70, 70));
        jButton1.setForeground(java.awt.Color.WHITE);
        jButton1.setOpaque(true); jButton1.setBorderPainted(false);
        jButton1.setMaximumSize(new java.awt.Dimension(Integer.MAX_VALUE, 42));
        jButton1.setPreferredSize(new java.awt.Dimension(800, 42));
        jButton1.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);
        jPanel1.add(jButton1);
        jPanel1.add(javax.swing.Box.createVerticalStrut(8));

        // ── Customer Request row ─────────────────────────────────────────────
        javax.swing.JPanel rowCust = row();
        jLabel1.setFont(bold);
        jTextField1.setFont(base); jTextField1.setPreferredSize(new java.awt.Dimension(280, 28));
        jComboBoxFrom.setFont(base); jComboBoxFrom.setPreferredSize(new java.awt.Dimension(120, 28));
        jButtonRename.setFont(bold);
        jComboBoxTo.setFont(base); jComboBoxTo.setPreferredSize(new java.awt.Dimension(120, 28));
        rowCust.add(jLabel1); rowCust.add(jTextField1);
        rowCust.add(javax.swing.Box.createHorizontalStrut(12));
        rowCust.add(jComboBoxFrom); rowCust.add(jButtonRename); rowCust.add(jComboBoxTo);
        jPanel1.add(rowCust);
        jPanel1.add(javax.swing.Box.createVerticalStrut(4));

        // ── Open Folder buttons (below Customer Request) ─────────────────────
        javax.swing.JPanel rowFolders = row();
        setBtn(jButton2, bold, new java.awt.Dimension(200, 30));
        setBtn(jButton7, bold, new java.awt.Dimension(200, 30));
        rowFolders.add(jButton2);
        rowFolders.add(javax.swing.Box.createHorizontalStrut(10));
        rowFolders.add(jButton7);
        jPanel1.add(rowFolders);
        jPanel1.add(javax.swing.Box.createVerticalStrut(8));

        // ── Dates + Buttons ──────────────────────────────────────────────────
        javax.swing.JPanel datesPanel = new javax.swing.JPanel(new java.awt.GridBagLayout());
        datesPanel.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);
        datesPanel.setOpaque(false);
        java.awt.GridBagConstraints gc = new java.awt.GridBagConstraints();
        gc.anchor = java.awt.GridBagConstraints.WEST;
        gc.fill   = java.awt.GridBagConstraints.NONE;
        gc.insets = new java.awt.Insets(3, 6, 3, 6);

        java.awt.Dimension fld = new java.awt.Dimension(110, 28);
        java.awt.Dimension btn = new java.awt.Dimension(170, 30);
        java.awt.Dimension btn2= new java.awt.Dimension(110, 30);

        setLbl(jLabel5, bold); jTextField2.setFont(base); jTextField2.setPreferredSize(fld);
        setLbl(jLabel7, bold); jTextField10.setFont(base); jTextField10.setPreferredSize(fld);
        setLbl(jLabel7b,bold); jTextField10b.setFont(base);jTextField10b.setPreferredSize(fld);
        setLbl(jLabel6, bold); jTextField3.setFont(base); jTextField3.setPreferredSize(fld);
        setBtn(jButton2, bold, btn); setBtn(jButton7, bold, btn);
        setBtn(jButton11,bold, btn); setBtn(jButton12,bold, btn2);
        setBtn(jButton3, bold, btn2);

        // row 0: Start Date
        addC(datesPanel, jLabel5, gc, 0,0); addC(datesPanel, jTextField2, gc, 1,0);
        addC(datesPanel, jButton11, gc, 2,0);  // Confirm Safari
        // row 1: Middle Date — Clear below Confirm Safari
        addC(datesPanel, jLabel7, gc, 0,1); addC(datesPanel, jTextField10, gc, 1,1);
        addC(datesPanel, jButton3, gc, 2,1);   // Clear (below Confirm Safari)
        // row 2: Middle Date 2
        addC(datesPanel, jLabel7b, gc, 0,2); addC(datesPanel, jTextField10b, gc, 1,2);
        // Status moved to menu bar (after Bookings)
        // row 3: End Date
        addC(datesPanel, jLabel6, gc, 0,3); addC(datesPanel, jTextField3, gc, 1,3);

        jPanel1.add(datesPanel);
        jPanel1.add(javax.swing.Box.createVerticalStrut(10));
        jPanel1.add(sep());

        // ── Checkbox section ─────────────────────────────────────────────────
        javax.swing.JPanel cbPanel = new javax.swing.JPanel(new java.awt.GridBagLayout());
        cbPanel.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);
        cbPanel.setOpaque(false);
        java.awt.GridBagConstraints cc = new java.awt.GridBagConstraints();
        cc.anchor = java.awt.GridBagConstraints.NORTHWEST;
        cc.fill   = java.awt.GridBagConstraints.NONE;
        cc.insets = new java.awt.Insets(2, 12, 2, 12);

        // Section headers
        setLbl(jLabel2, head); setLbl(jLabel3, head); setLbl(jLabel4, head); setLbl(jLabel14, head);
        addC(cbPanel, jLabel2,  cc, 0,0, 2,1);
        addC(cbPanel, jLabel3,  cc, 2,0);
        addC(cbPanel, jLabel4,  cc, 3,0);
        addC(cbPanel, jLabel14, cc, 4,0);

        // Apply font to all checkboxes
        for (javax.swing.JCheckBox c : new javax.swing.JCheckBox[]{
            jCheckBox1,jDumaShort,jCheckBox2,jCheckBox3,Simba2,Simba3,
            jCheckBox4,jCheckBox5,jCheckBox27,jCheckBox6,jCheckBox7,jCheckBox8,
            GranSafari,jCheckBox11,jCheckBox12,jCheckBox13,jCheckBox28,jCheckBox9,
            ThursdayGRP,SundayGRP,
            BeachDumaShort,jCheckBox16,jCheckBox24,jCheckBox17,DumaPemba,PumbaPemba,SimbaPemba,jCheckBox22,
            machame,machame6,jCheckBox19,Marangu7days,jCheckBox25,jCheckBox26,Lemosho10days,
            jLuxDuma,jLuxPumba,jLuxSimba,jDC,jPC,jSC,jKC
        }) c.setFont(base);

        // Col 0: main Safari
        javax.swing.JCheckBox[] col0 = {jCheckBox1,jDumaShort,jCheckBox2,jCheckBox3,
            Simba2,Simba3,jCheckBox4,jCheckBox5,jCheckBox27,jCheckBox6,jCheckBox7,jCheckBox8};
        for (int i=0;i<col0.length;i++) addC(cbPanel,col0[i],cc,0,i+1);

        // Col 1: GRP + Migration
        javax.swing.JCheckBox[] col1 = {GranSafari,jCheckBox11,jCheckBox12,jCheckBox13,
            jCheckBox28,jCheckBox9,ThursdayGRP,SundayGRP};
        for (int i=0;i<col1.length;i++) addC(cbPanel,col1[i],cc,1,i+1);

        // Col 2: Beach (header jLabel8 then checkboxes)
        jLabel8.setFont(head);
        addC(cbPanel, jLabel8, cc, 2, 1);
        javax.swing.JCheckBox[] col2 = {BeachDumaShort,jCheckBox16,jCheckBox24,
            jCheckBox17,DumaPemba,PumbaPemba,SimbaPemba,jCheckBox22};
        for (int i=0;i<col2.length;i++) addC(cbPanel,col2[i],cc,2,i+2);

        // Col 3: Trekking
        javax.swing.JCheckBox[] col3 = {machame,machame6,jCheckBox19,Marangu7days,
            jCheckBox25,jCheckBox26,Lemosho10days};
        for (int i=0;i<col3.length;i++) addC(cbPanel,col3[i],cc,3,i+1);

        // Col 4: LUX
        javax.swing.JCheckBox[] col4 = {jLuxDuma,jLuxPumba,jLuxSimba,jDC,jPC,jSC,jKC};
        for (int i=0;i<col4.length;i++) addC(cbPanel,col4[i],cc,4,i+1);

        // Clear Checkbox / Copy Programs / ProgNum — below Safari column
        int cbRow = col0.length + 2;
        setBtn(jButton5, bold, new java.awt.Dimension(130, 28));
        setBtn(jButton4, bold, new java.awt.Dimension(130, 28));
        jLabel9.setFont(base);
        jTextField4.setFont(base); jTextField4.setPreferredSize(new java.awt.Dimension(46, 26));
        addC(cbPanel, jButton5, cc, 0, cbRow);
        addC(cbPanel, jButton4, cc, 1, cbRow);
        addC(cbPanel, jLabel9,  cc, 2, cbRow);
        addC(cbPanel, jTextField4, cc, 3, cbRow);

        jPanel1.add(javax.swing.Box.createVerticalStrut(6));
        jPanel1.add(cbPanel);
        jPanel1.add(javax.swing.Box.createVerticalStrut(8));
        jPanel1.add(sep());

        // ── Rename in Folder ─────────────────────────────────────────────────
        javax.swing.JPanel rowRenF = row();
        jLabel10.setFont(bold);
        jTextField5.setFont(base); jTextField5.setPreferredSize(new java.awt.Dimension(130, 28));
        rowRenF.add(jLabel10); rowRenF.add(jTextField5);
        jPanel1.add(rowRenF);
        jPanel1.add(javax.swing.Box.createVerticalStrut(4));

        // ── Current / New name ───────────────────────────────────────────────
        java.awt.Dimension nameFld = new java.awt.Dimension(360, 26);
        javax.swing.JPanel rowCurr = row();
        jLabel11.setFont(bold); jTextField6.setFont(base); jTextField6.setPreferredSize(nameFld);
        rowCurr.add(jLabel11); rowCurr.add(jTextField6);
        jPanel1.add(rowCurr);
        jPanel1.add(javax.swing.Box.createVerticalStrut(4));

        javax.swing.JPanel rowNew = row();
        jLabel12.setFont(bold); jTextField7.setFont(base); jTextField7.setPreferredSize(nameFld);
        rowNew.add(jLabel12); rowNew.add(jTextField7);
        jPanel1.add(rowNew);
        jPanel1.add(javax.swing.Box.createVerticalStrut(6));

        // ── Rename buttons ───────────────────────────────────────────────────
        javax.swing.JPanel rowRenBtns = row();
        setBtn(jButton15, bold, null); setBtn(jButtonClearRename, bold, null);
        setBtn(jButtonToCustomerFile, bold, null);
        rowRenBtns.add(jButton15); rowRenBtns.add(jButtonClearRename); rowRenBtns.add(jButtonToCustomerFile);
        jPanel1.add(rowRenBtns);
        jPanel1.add(javax.swing.Box.createVerticalStrut(8));
        jPanel1.add(sep());

        // ── Search ───────────────────────────────────────────────────────────
        javax.swing.JPanel rowSearch = row();
        java.awt.Dimension sFld = new java.awt.Dimension(280, 26);
        setBtn(jButton17, bold, new java.awt.Dimension(180, 30));
        jTextField8.setFont(base); jTextField8.setPreferredSize(sFld);
        setBtn(jButton18, bold, new java.awt.Dimension(200, 30));
        jTextField9.setFont(base); jTextField9.setPreferredSize(sFld);
        rowSearch.add(jButton17); rowSearch.add(jTextField8);
        rowSearch.add(javax.swing.Box.createHorizontalStrut(16));
        rowSearch.add(jButton18); rowSearch.add(jTextField9);
        jPanel1.add(rowSearch);
        jPanel1.add(javax.swing.Box.createVerticalStrut(4));

        javax.swing.JPanel rowSubSearch = row();
        setBtn(jButton14, bold, null);
        jTextField11.setFont(base); jTextField11.setPreferredSize(new java.awt.Dimension(280, 26));
        rowSubSearch.add(jButton14); rowSubSearch.add(jTextField11);
        jPanel1.add(rowSubSearch);
        jPanel1.add(javax.swing.Box.createVerticalStrut(14));

        // ── Content pane ─────────────────────────────────────────────────────
        jScrollPane2.setViewportView(jPanel1);
        jScrollPane2.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        jScrollPane2.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
        getContentPane().setLayout(new java.awt.BorderLayout());
        getContentPane().add(jScrollPane2, java.awt.BorderLayout.CENTER);
    }

    private javax.swing.JPanel row() {
        javax.swing.JPanel p = new javax.swing.JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 6, 0));
        p.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);
        p.setOpaque(false);
        return p;
    }
    private javax.swing.JSeparator sep() {
        javax.swing.JSeparator s = new javax.swing.JSeparator();
        s.setMaximumSize(new java.awt.Dimension(Integer.MAX_VALUE, 2));
        s.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);
        return s;
    }
    private void setLbl(javax.swing.JLabel l, java.awt.Font f) { l.setFont(f); }
    private void setBtn(javax.swing.JButton b, java.awt.Font f, java.awt.Dimension d) {
        b.setFont(f);
        if (d != null) b.setPreferredSize(d);
    }
    private void addC(javax.swing.JPanel p, java.awt.Component c,
                      java.awt.GridBagConstraints gc, int x, int y) {
        gc.gridx=x; gc.gridy=y; gc.gridwidth=1; gc.gridheight=1; p.add(c, gc);
    }
    private void addC(javax.swing.JPanel p, java.awt.Component c,
                      java.awt.GridBagConstraints gc, int x, int y, int w, int h) {
        gc.gridx=x; gc.gridy=y; gc.gridwidth=w; gc.gridheight=h; p.add(c, gc);
        gc.gridwidth=1; gc.gridheight=1;
    }


    private void jMenu4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenu4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jMenu4ActionPerformed

    private void jMenuItem6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem6ActionPerformed
        // List GRP groups: cattura output, filtra solo 01_..12_, mostra popup
        String dirCmd = "dir /b \"%DROPBOX_HOME%\\001_Safari\\*GRP*\"";
        java.util.List<String> all = runDirCommand(dirCmd);
        java.util.List<String> filtered = new java.util.ArrayList<>();
        for (String line : all) {
            if (line.matches("^(0[1-9]|1[0-2])_.*")) {
                filtered.add(line);
            }
        }
        showResultsPopup("GRP Groups", filtered);
    }//GEN-LAST:event_jMenuItem6ActionPerformed

    private void jMenuItem17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem17ActionPerformed
        // TODO add your handling code here:
        try {
            String mycmd="cmd /c explorer.exe %DROPBOX_HOME%\\000_Contracts\\Zanzibar";
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(mycmd);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }
    }//GEN-LAST:event_jMenuItem17ActionPerformed

    private void jMenuItem16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem16ActionPerformed
        // TODO add your handling code here:
        try {
            String mycmd="cmd /c explorer.exe %DROPBOX_HOME%\\000_Contracts";
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(mycmd);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }
    }//GEN-LAST:event_jMenuItem16ActionPerformed

    private void jMenuItem13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem13ActionPerformed
        // TODO add your handling code here:
        try {
            String mycmd="cmd /c explorer.exe %DROPBOX_HOME%\\001_Safari";
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(mycmd);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }
    }//GEN-LAST:event_jMenuItem13ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        // Open folder "Agenzia"
        try {
            String mycmd="cmd /c explorer.exe %DROPBOX_HOME%\\itineraries\\SafariClassic\\it\\Agenzia";
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(mycmd);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        // Replicates MissingCK.bat:
        // List dated folders in 001_Safari whose NAME does NOT contain "CK".
        // Also excludes PROGRESS/PROVISIONAL (not yet confirmed) and
        // destinations that don't require CK (Kenya, Uganda, Namibia, etc.).
        String dropboxHome = System.getenv("DROPBOX_HOME");
        if (dropboxHome == null || dropboxHome.isEmpty()) {
            showScriptOutputPopup("Missing CK", "DROPBOX_HOME environment variable is not set.", true);
            return;
        }
        java.io.File safariDir = new java.io.File(dropboxHome + "\\001_Safari");
        if (!safariDir.exists() || !safariDir.isDirectory()) {
            showScriptOutputPopup("Missing CK",
                "001_Safari folder not found:\n" + safariDir.getAbsolutePath(), true);
            return;
        }

        // Matches FILTERS in MissingCK.bat — folders containing any of these are excluded
        String[] excludeWords = {
            "CK", "PROGRESS", "PROVISIONAL",
            "KENYA", "UGANDA", "NAMIBIA", "SUDAFRICA", "MADAGASCAR"
        };

        java.util.List<String> missing = new java.util.ArrayList<>();
        java.io.File[] folders = safariDir.listFiles(java.io.File::isDirectory);
        if (folders != null) {
            java.util.Arrays.sort(folders, (a, b) -> a.getName().compareToIgnoreCase(b.getName()));
            for (java.io.File folder : folders) {
                String name = folder.getName();
                // Only dated folders: MM_...
                if (!name.matches("^(0[1-9]|1[0-2])_.*")) continue;
                // Exclude if folder name contains any filter word (case-insensitive)
                String nameUpper = name.toUpperCase();
                boolean excluded = false;
                for (String word : excludeWords) {
                    if (nameUpper.contains(word)) { excluded = true; break; }
                }
                if (!excluded) missing.add(name);
            }
        }

        if (missing.isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this,
                "All confirmed safaris have CK. Nothing missing.",
                "Missing CK", javax.swing.JOptionPane.INFORMATION_MESSAGE);
        } else {
            showResultsPopup("Missing CK — " + missing.size() + " folder(s)", missing);
        }
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jMenuItem4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem4ActionPerformed
        String mycmd = "dir /b \"%DROPBOX_HOME%\\001_Safari\\*PROGRESS*\"";
        java.util.List<String> results = runDirCommand(mycmd);
        showResultsPopup("PROGRESS folders", results);
    }//GEN-LAST:event_jMenuItem4ActionPerformed

    private void jDCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jDCActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jDCActionPerformed

    private void jLuxDumaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jLuxDumaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jLuxDumaActionPerformed

    private void jTextField10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField10ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField10ActionPerformed

    private void jTextField10bActionPerformed(java.awt.event.ActionEvent evt) {
        // TODO add your handling code here:
    }

    private void Simba3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Simba3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Simba3ActionPerformed

    private void SundayGRPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SundayGRPActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SundayGRPActionPerformed

    private void Marangu7daysActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Marangu7daysActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Marangu7daysActionPerformed

    private void jSearchSafariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jSearchSafariActionPerformed
        String dropbox_home = System.getenv("DROPBOX_HOME");
        String path = dropbox_home + "\\" + "001_Safari";
        showBrowsePopup("Browse 001_Safari", path);
    }//GEN-LAST:event_jSearchSafariActionPerformed

    private void jSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jSearchActionPerformed
        String dropbox_home = System.getenv("DROPBOX_HOME");
        String req_year = System.getenv("REQ_YEAR");
        String path = dropbox_home + "\\" + req_year;
        showBrowsePopup("Browse " + req_year, path);
    }//GEN-LAST:event_jSearchActionPerformed

    private void jButtonRenameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonRenameActionPerformed
        String folderName = jTextField1.getText().trim();
        if (folderName.isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this,
                "Customer File is empty. Please select a folder first.",
                "Rename", javax.swing.JOptionPane.WARNING_MESSAGE);
            return;
        }
        String fromStatus = (String) jComboBoxFrom.getSelectedItem();
        String toStatus   = (String) jComboBoxTo.getSelectedItem();
        if (fromStatus.equals(toStatus)) {
            javax.swing.JOptionPane.showMessageDialog(this,
                "FROM and TO values are the same. Nothing to rename.",
                "Rename", javax.swing.JOptionPane.WARNING_MESSAGE);
            return;
        }

        String newFolderName;

        if ("PAID".equals(fromStatus)) {
            // FROM=PAID: folder must not already contain any status tag
            String[] allStatuses = {"PROGRESS","PROVISIONAL","DEPOSIT","BALANCE","BALANCE-CASH","CANCELLED"};
            String foundTag = null;
            for (String s : allStatuses) {
                if (folderName.contains("_" + s)) { foundTag = s; break; }
            }
            if (foundTag != null) {
                javax.swing.JOptionPane.showMessageDialog(this,
                    "The folder already contains the status \"_" + foundTag + "\":\n" + folderName,
                    "Rename", javax.swing.JOptionPane.WARNING_MESSAGE);
                return;
            }
            // Safe to append
            newFolderName = folderName + "_" + toStatus;
        } else if ("PAID".equals(toStatus)) {
            // TO=PAID: remove _FROM tag, nothing added
            if (!folderName.contains("_" + fromStatus)) {
                javax.swing.JOptionPane.showMessageDialog(this,
                    "The string \"_" + fromStatus + "\" was not found in:\n" + folderName,
                    "Rename", javax.swing.JOptionPane.WARNING_MESSAGE);
                return;
            }
            newFolderName = folderName.replace("_" + fromStatus, "");
        } else {
            // Normal case: replace _FROM with _TO
            if (!folderName.contains("_" + fromStatus)) {
                javax.swing.JOptionPane.showMessageDialog(this,
                    "The string \"_" + fromStatus + "\" was not found in:\n" + folderName,
                    "Rename", javax.swing.JOptionPane.WARNING_MESSAGE);
                return;
            }
            newFolderName = folderName.replace("_" + fromStatus, "_" + toStatus);
        }
        String base = System.getenv("DROPBOX_HOME") + "\\001_Safari\\";
        java.io.File oldFolder = new java.io.File(base + folderName);
        java.io.File newFolder = new java.io.File(base + newFolderName);
        if (!oldFolder.exists()) {
            javax.swing.JOptionPane.showMessageDialog(this,
                "Folder not found on disk:\n" + oldFolder.getAbsolutePath(),
                "Rename", javax.swing.JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (!oldFolder.renameTo(newFolder)) {
            javax.swing.JOptionPane.showMessageDialog(this,
                "Rename failed. The folder may be open or locked:\n" + oldFolder.getAbsolutePath(),
                "Rename", javax.swing.JOptionPane.ERROR_MESSAGE);
            return;
        }
        jTextField1.setText(newFolderName);

        // ── Update DB via API ─────────────────────────────────────────────────
        if (USE_API && AppSession.isLoggedIn()) {
            final String oldName = folderName;
            final String newName = newFolderName;
            new Thread(() -> {
                try {
                    String body = "{\"old_folder_name\":\"" + oldName.replace("\\","\\\\").replace("\"","\\\"")
                                + "\",\"new_folder_name\":\"" + newName.replace("\\","\\\\").replace("\"","\\\"")
                                + "\"}";
                    String resp = postApiDirect("api_rename_folder.php", body);
                    if (resp == null || !resp.contains("\"success\":true")) {
                        javax.swing.SwingUtilities.invokeLater(() ->
                            javax.swing.JOptionPane.showMessageDialog(this,
                                "Folder renamed on disk.\nDB update warning: " + resp,
                                "Rename", javax.swing.JOptionPane.WARNING_MESSAGE));
                    }
                } catch (Exception ex) {
                    javax.swing.SwingUtilities.invokeLater(() ->
                        javax.swing.JOptionPane.showMessageDialog(this,
                            "Folder renamed on disk.\nDB update failed: " + ex.getMessage(),
                            "Rename", javax.swing.JOptionPane.WARNING_MESSAGE));
                }
            }).start();
        }
    }//GEN-LAST:event_jButtonRenameActionPerformed

    private void BtoPaidFullActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtoPaidFullActionPerformed
    }//GEN-LAST:event_BtoPaidFullActionPerformed

    private void DtoBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DtoBActionPerformed
    }//GEN-LAST:event_DtoBActionPerformed

    private void PtoBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PtoBActionPerformed
    }//GEN-LAST:event_PtoBActionPerformed

    private void PtoDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PtoDActionPerformed
    }//GEN-LAST:event_PtoDActionPerformed

    private void BeachDumaShortActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BeachDumaShortActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BeachDumaShortActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
        String custnamein=jTextField1.getText();
        String custname=custnamein.replaceAll("\\s", "");
        // Open folder in Windows Explorers
        try {
            String mycmd="cmd /c explorer.exe \"%DROPBOX_HOME%\\001_Safari\\\"" + custname;
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(mycmd);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jDumaShortActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jDumaShortActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jDumaShortActionPerformed

    private void machame6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_machame6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_machame6ActionPerformed

    private void PumbaPembaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PumbaPembaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PumbaPembaActionPerformed

    private void DumaPembaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DumaPembaActionPerformed
        // TODO add your handling code here:
        try {
            String mycmd="cmd /c explorer.exe \"%DROPBOX_HOME%\\000_Contracts\\Zanzibar\"";
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(mycmd);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }
    }//GEN-LAST:event_DumaPembaActionPerformed

    private void jButton18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton18ActionPerformed
        String mytext1 = jTextField9.getText();
        String mytext = mytext1.replaceAll("\\s", "");
        String mycmd = "dir /b \"%DROPBOX_HOME%\\001_Safari\\\"*" + mytext + "*";
        java.util.List<String> results = runDirCommand(mycmd);
        showResultsPopup("Search 001_Safari Folder — " + mytext, results);
    }//GEN-LAST:event_jButton18ActionPerformed

    private void jButton17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton17ActionPerformed
        String mytext1 = jTextField8.getText();
        String mytext = mytext1.replaceAll("\\s", "");
        String mycmd = "dir /b \"%DROPBOX_HOME%\\%REQ_YEAR%\\\"*" + mytext + "*";
        java.util.List<String> results = runDirCommand(mycmd);
        showResultsPopup("Search 2026 Folder — " + mytext, results);
    }//GEN-LAST:event_jButton17ActionPerformed

    private void jTextField8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField8ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField8ActionPerformed

    private void jTextField7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField7ActionPerformed

    private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton15ActionPerformed
        try {
            String foldername = jTextField5.getSelectedItem() != null ? jTextField5.getSelectedItem().toString() : "";
            String currentname = jTextField6.getText().trim();
            String newname = jTextField7.getText().trim();
            if (currentname.isEmpty() || newname.isEmpty()) {
                javax.swing.JOptionPane.showMessageDialog(this,
                    "Please fill in both Current name and New name.", "Rename",
                    javax.swing.JOptionPane.WARNING_MESSAGE);
                return;
            }
            String dropboxHome = System.getenv("DROPBOX_HOME");
            if (dropboxHome == null) dropboxHome = "%DROPBOX_HOME%";
            java.io.File source = new java.io.File(dropboxHome + "\\" + foldername + "\\" + currentname);
            java.io.File dest   = new java.io.File(dropboxHome + "\\" + foldername + "\\" + newname);
            if (!source.exists()) {
                javax.swing.JOptionPane.showMessageDialog(this,
                    "Source not found:\n" + source.getAbsolutePath(), "Rename Error",
                    javax.swing.JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (!source.renameTo(dest)) {
                javax.swing.JOptionPane.showMessageDialog(this,
                    "Rename failed (access denied or file in use):\n" + source.getAbsolutePath(), "Rename Error",
                    javax.swing.JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            javax.swing.JOptionPane.showMessageDialog(this,
                "Unexpected error during rename:\n" + ex.getMessage(), "Rename Error",
                javax.swing.JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jButton15ActionPerformed

    private void jButtonClearRenameActionPerformed(java.awt.event.ActionEvent evt) {
        jTextField6.setText("");
        jTextField7.setText("");
    }

    private void jButtonToCustomerFileActionPerformed(java.awt.event.ActionEvent evt) {
        String newname = jTextField7.getText().trim();
        if (newname.isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this,
                "New name field is empty.", "Customer File",
                javax.swing.JOptionPane.WARNING_MESSAGE);
            return;
        }
        jTextField1.setText(newname);
    }

    private void jCheckBox27ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox27ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox27ActionPerformed

    private void jCheckBox26ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox26ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox26ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
        // TODO add your handling code here:
        // Remome string "OPEN" in all the file names
        try {
            String mycmd="cmd /c start /D \"%DROPBOX_HOME%\\SavannahScripts\\\" \" \" Status.bat";
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(mycmd);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }
    }//GEN-LAST:event_jButton12ActionPerformed

    private void jCheckBox22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox22ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox22ActionPerformed

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField2ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        // Safari is confirmed with Start Date, End Date and other info
        // Generate the new safari folder and move to confirmed safari folder %DROPBOX_HOME%\\001_Safari
        String custname=jTextField1.getText();
        String startdatein=jTextField2.getText();
        String startdate=startdatein.toUpperCase();
        String intdatein=jTextField10.getText();
        String intdate=intdatein.toUpperCase();
        String intdate2in=jTextField10b.getText();
        String intdate2=intdate2in.toUpperCase();
        String enddatein=jTextField3.getText();
        String enddate=enddatein.toUpperCase();
        String month = "00";
        String endmonth = "00";
        String confirmedfolder = "00";
                
        if (startdate.matches("(?i).*JAN.*"))
        {
            month="01";
        }
        if (startdate.matches("(?i).*FEB.*"))
        {
            month="02";
        }
        if (startdate.matches("(?i).*MAR.*"))
        {
            month="03";
        }
        if (startdate.matches("(?i).*APR.*"))
        {
            month="04";
        }
        if (startdate.matches("(?i).*MAY.*"))
        {
            month="05";
        }
        if (startdate.matches("(?i).*JUN.*"))
        {
            month="06";
        }
        if (startdate.matches("(?i).*JUL.*"))
        {
            month="07";
        }
        if (startdate.matches("(?i).*AUG.*"))
        {
            month="08";
        }
        if (startdate.matches("(?i).*SEP.*"))
        {
            month="09";
        }
        if (startdate.matches("(?i).*OCT.*"))
        {
            month="10";
        }
        if (startdate.matches("(?i).*NOV.*"))
        {
            month="11";
        }
        if (startdate.matches("(?i).*DEC.*"))
        {
            month="12";
        }
        
        if (month.equals("00"))
        {
            //Terminates program and don't confirm safari as there is incorrect middle date
                        JOptionPane.showMessageDialog(null, "Incorrect Start Date Month, the correct format is MMM, for example JAN. We can't confirm the safari, check the dates and try again", "DATE ERROR", JOptionPane.ERROR_MESSAGE);
            //System.exit(0);
            return;
        }      

        if ((intdate.matches("(?i).*NA.*")) || (intdate == null) || (intdate.trim().isEmpty()))
        {
            // no middle date 1 — ignore middle date 2 as well
            confirmedfolder=month+"_"+startdate+"_"+custname+"_START"+startdate+"_END"+enddate+"_PROGRESS";
        }
        else if ((intdate.length() != 5))
        {
            JOptionPane.showMessageDialog(null, "Incorrect Middle Date, the correct format is DDMMM, for example 10JAN. We can't confirm the safari, check the dates and try again", "DATE ERROR", JOptionPane.ERROR_MESSAGE);
            return;
        }
        else
        {
            // middle date 1 is valid — check middle date 2
            boolean hasIntDate2 = !intdate2.matches("(?i).*NA.*") && !intdate2.trim().isEmpty();
            if (hasIntDate2 && intdate2.length() != 5)
            {
                JOptionPane.showMessageDialog(null, "Incorrect Middle Date 2, the correct format is DDMMM, for example 10JAN. We can't confirm the safari, check the dates and try again", "DATE ERROR", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (hasIntDate2)
            {
                confirmedfolder=month+"_"+startdate+"_"+custname+"_START"+startdate+"_MIDT"+intdate+"_MIDT"+intdate2+"_END"+enddate+"_PROGRESS";
            }
            else
            {
                confirmedfolder=month+"_"+startdate+"_"+custname+"_START"+startdate+"_MIDT"+intdate+"_END"+enddate+"_PROGRESS";
            }
        }

        if (month.matches("(?i).*00.*"))
        {
            JOptionPane.showMessageDialog(null, "Missing/Incorrect START, MIDDLE or END Date, we can't confirm the safari, check the dates and try again", "DATE ERROR", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if ((startdate.matches("(?i).*NA.*")) || (startdate.length() != 5))
        {
            JOptionPane.showMessageDialog(null, "Missing/Incorrect START Date, the correct format is DDMMM, for example 10JAN. We can't confirm the safari, check the dates and try again", "DATE ERROR", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if ((enddate.matches("(?i).*NA.*")) || (enddate.length() != 9))
        {
            JOptionPane.showMessageDialog(null, " Missing/Incorrect END Date, the correct format is DDMMMYYYY, for example 10JAN2025. We can't confirm the safari, check the dates and try again", "DATE ERROR", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Checking if end month is correct      
        if (enddate.matches("(?i).*JAN.*")) { endmonth="01"; }
        if (enddate.matches("(?i).*FEB.*")) { endmonth="02"; }
        if (enddate.matches("(?i).*MAR.*")) { endmonth="03"; }
        if (enddate.matches("(?i).*APR.*")) { endmonth="04"; }
        if (enddate.matches("(?i).*MAY.*")) { endmonth="05"; }
        if (enddate.matches("(?i).*JUN.*")) { endmonth="06"; }
        if (enddate.matches("(?i).*JUL.*")) { endmonth="07"; }
        if (enddate.matches("(?i).*AUG.*")) { endmonth="08"; }
        if (enddate.matches("(?i).*SEP.*")) { endmonth="09"; }
        if (enddate.matches("(?i).*OCT.*")) { endmonth="10"; }
        if (enddate.matches("(?i).*NOV.*")) { endmonth="11"; }
        if (enddate.matches("(?i).*DEC.*")) { endmonth="12"; }
        
        if (endmonth.equals("00"))
        {
            JOptionPane.showMessageDialog(null, "Incorrect End Date Month, the correct format is MMM, for example JAN. We can't confirm the safari, check the dates and try again", "DATE ERROR", JOptionPane.ERROR_MESSAGE);
            return;
        }  

        // confirmedfolder is now set — run all heavy work off the EDT
        final String oldFolder = custname;
        final String newFolder = confirmedfolder;

        jButton11.setEnabled(false);
        jButton11.setText("Working…");

        new SwingWorker<String, Void>() {
            @Override
            protected String doInBackground() throws Exception {
                String dropboxHome = System.getenv("DROPBOX_HOME");
                String reqYear     = System.getenv("REQ_YEAR");
                if (dropboxHome == null) dropboxHome = "";
                if (reqYear    == null) reqYear      = "2026";
                StringBuilder log = new StringBuilder();

                // ── Step 1: rename folder in year directory ──────────────────
                ProcessBuilder pb1 = new ProcessBuilder("cmd", "/c", "rename", oldFolder, newFolder);
                pb1.directory(new File(dropboxHome + "\\" + reqYear));
                pb1.redirectErrorStream(true);
                Process pr1 = pb1.start();
                try (BufferedReader r1 = new BufferedReader(new InputStreamReader(pr1.getInputStream()))) {
                    String ln;
                    while ((ln = r1.readLine()) != null) { if (!ln.isBlank()) log.append(ln).append("\n"); }
                }
                int exit1 = pr1.waitFor();
                if (exit1 != 0) {
                    return "ERROR_RENAME:Rename failed (exit " + exit1 + ")"
                           + (log.length() > 0 ? ":\n" + log : "");
                }
                log.append("✔ Folder renamed → ").append(newFolder).append("\n");

                // ── Step 2: wait for Dropbox sync (10 s, safe off EDT) ───────
                Thread.sleep(10_000);

                // ── Step 3: run cfolders.bat ──────────────────────────────────
                ProcessBuilder pb2 = new ProcessBuilder("cmd", "/c", "cfolders.bat", newFolder);
                pb2.directory(new File(dropboxHome + "\\SavannahScripts"));
                pb2.redirectErrorStream(true);
                Process pr2 = pb2.start();
                StringBuilder bat2 = new StringBuilder();
                try (BufferedReader r2 = new BufferedReader(new InputStreamReader(pr2.getInputStream()))) {
                    String ln;
                    while ((ln = r2.readLine()) != null) { if (!ln.isBlank()) bat2.append(ln).append("\n"); }
                }
                pr2.waitFor(); // exit code ignored — 'sleep' not found on Windows causes exit 1 even on success

                // Verify by checking the destination folder exists in 001_Safari
                File destFolder = new File(dropboxHome + "\\001_Safari\\" + newFolder);
                if (!destFolder.exists() || !destFolder.isDirectory()) {
                    return "ERROR_MOVE:Folder not found in 001_Safari after cfolders.bat.\nExpected: "
                           + destFolder.getAbsolutePath()
                           + (bat2.length() > 0 ? "\n\nScript output:\n" + bat2 : "");
                }
                if (bat2.length() > 0) log.append(bat2);
                log.append("✔ Moved to 001_Safari\n");

                // ── Step 4: update DB via API (when API is configured) ────────
                if (USE_API && AppSession.isLoggedIn()) {
                    try {
                        String body = "{\"old_folder_name\":\"" + escJson(oldFolder)
                                    + "\",\"new_folder_name\":\"" + escJson(newFolder) + "\"}";
                        String resp = postApiDirect("api_confirm_safari.php", body);
                        if (resp != null && resp.contains("\"success\":true")) {
                            log.append("✔ DB updated: status → Booked\n");
                        } else {
                            log.append("⚠ DB update returned: ").append(resp).append("\n");
                        }
                    } catch (Exception ex) {
                        log.append("⚠ DB update error: ").append(ex.getMessage()).append("\n");
                    }
                }

                return "OK:" + log.toString();
            }

            @Override
            protected void done() {
                jButton11.setEnabled(true);
                jButton11.setText("Confirm Safari");
                try {
                    String result = get();
                    if (result.startsWith("ERROR_RENAME:")) {
                        showScriptOutputPopup("Confirm Safari — Rename Error",
                            result.substring("ERROR_RENAME:".length()), true);
                    } else if (result.startsWith("ERROR_MOVE:")) {
                        showScriptOutputPopup("Confirm Safari — Move Error",
                            result.substring("ERROR_MOVE:".length()), true);
                    } else {
                        jTextField1.setText(newFolder); // populate Customer Request with confirmed folder name
                        showScriptOutputPopup("Confirm Safari — Done",
                            result.substring("OK:".length()), false);
                    }
                } catch (java.util.concurrent.ExecutionException ex) {
                    showScriptOutputPopup("Confirm Safari — Error",
                        ex.getCause() != null ? ex.getCause().getMessage() : ex.getMessage(), true);
                } catch (Exception ex) {
                    showScriptOutputPopup("Confirm Safari — Error", ex.getMessage(), true);
                }
            }

            /** Escape a string for inline JSON. */
            private String escJson(String s) {
                if (s == null) return "";
                return s.replace("\\", "\\\\").replace("\"", "\\\"");
            }
        }.execute();
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jCheckBox19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox19ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox19ActionPerformed

    private void machameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_machameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_machameActionPerformed

    private void jCheckBox16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox16ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox16ActionPerformed

    private void jCheckBox12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox12ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox12ActionPerformed

    private void jCheckBox7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox7ActionPerformed

    private void jCheckBox5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox5ActionPerformed

    private void jCheckBox4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox4ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        System.exit(0);
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        jCheckBox1.setSelected(false);
        jCheckBox2.setSelected(false);
        jCheckBox3.setSelected(false);
        jCheckBox4.setSelected(false);
        jCheckBox5.setSelected(false);
        jCheckBox6.setSelected(false);
        jCheckBox7.setSelected(false);
        jCheckBox8.setSelected(false);

        jCheckBox11.setSelected(false);
        jCheckBox12.setSelected(false);
        jCheckBox13.setSelected(false);
        

        jCheckBox16.setSelected(false);
        jCheckBox17.setSelected(false);
        machame.setSelected(false);
        jCheckBox19.setSelected(false);
        jDumaShort.setSelected(false);
        Simba2.setSelected(false);
        Simba3.setSelected(false);
        jCheckBox27.setSelected(false);
        GranSafari.setSelected(false);
        
        
        jCheckBox28.setSelected(false);
        ThursdayGRP.setSelected(false);
        SundayGRP.setSelected(false);
        BeachDumaShort.setSelected(false);
        jCheckBox24.setSelected(false);
        DumaPemba.setSelected(false);
        PumbaPemba.setSelected(false);
        SimbaPemba.setSelected(false);
        jCheckBox22.setSelected(false);
        machame6.setSelected(false);
        Marangu7days.setSelected(false);
        jCheckBox25.setSelected(false);
        jCheckBox26.setSelected(false);
        Lemosho10days.setSelected(false);
        jLuxDuma.setSelected(false);
        jLuxPumba.setSelected(false);
        jLuxSimba.setSelected(false);
        jDC.setSelected(false);
        jPC.setSelected(false);
        jSC.setSelected(false);
        jKC.setSelected(false);
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:

        // set customer name, i.e. folder
        String custname=jTextField1.getText();

        // set program number
        String prognum=jTextField4.getText();

        // Copy Programs in Italian lang for the checked programs
        if (jCheckBox1.isSelected()==true)
        try {
            String newcust="cmd /c start /D \"%DROPBOX_HOME%\\SavannahScripts\\\" \" \" cpDuma.bat " + custname + " " + prognum;
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(newcust);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }
        if (jDumaShort.isSelected()==true)
        try {
            String newcust="cmd /c start /D \"%DROPBOX_HOME%\\SavannahScripts\\\" \" \" cpDumaShort.bat " + custname + " " + prognum;
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(newcust);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }

        if (jCheckBox2.isSelected()==true)
        try {
            String newcust="cmd /c start /D \"%DROPBOX_HOME%\\SavannahScripts\\\" \" \" cpPumba.bat " + custname + " " + prognum;
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(newcust);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }

        if (jCheckBox3.isSelected()==true)
        try {
            String newcust="cmd /c start /D \"%DROPBOX_HOME%\\SavannahScripts\\\" \" \" cpSimba.bat " + custname + " " + prognum;
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(newcust);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }

        if (jCheckBox4.isSelected()==true)
        try {
            String newcust="cmd /c start /D \"%DROPBOX_HOME%\\SavannahScripts\\\" \" \" cpKiboko.bat " + custname + " " + prognum;
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(newcust);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }

        if (jCheckBox5.isSelected()==true)
        try {
            String newcust="cmd /c start /D \"%DROPBOX_HOME%\\SavannahScripts\\\" \" \" cpTembo.bat " + custname + " " + prognum;
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(newcust);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }

        if (jCheckBox6.isSelected()==true)
        try {
            String newcust="cmd /c start /D \"%DROPBOX_HOME%\\SavannahScripts\\\" \" \" cpChui.bat " + custname + " " + prognum;
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(newcust);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }

        if (jCheckBox7.isSelected()==true)
        try {
            String newcust="cmd /c start /D \"%DROPBOX_HOME%\\SavannahScripts\\\" \" \" cpFaru.bat " + custname + " " + prognum;
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(newcust);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }

        if (jCheckBox8.isSelected()==true)
        try {
            String newcust="cmd /c start /D \"%DROPBOX_HOME%\\SavannahScripts\\\" \" \" cpMbogo.bat " + custname + " " + prognum;
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(newcust);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }
        
        if (jCheckBox9.isSelected()==true)
        try {
            String newcust="cmd /c start /D \"%DROPBOX_HOME%\\SavannahScripts\\\" \" \" cpGombeKatavi.bat " + custname + " " + prognum;
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(newcust);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }

        if (jCheckBox11.isSelected()==true)
        try {
            String newcust="cmd /c start /D \"%DROPBOX_HOME%\\SavannahScripts\\\" \" \" cpGMI.bat " + custname + " " + prognum;
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(newcust);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }

        if (jCheckBox12.isSelected()==true)
        try {
            String newcust="cmd /c start /D \"%DROPBOX_HOME%\\SavannahScripts\\\" \" \" cpGME.bat " + custname + " " + prognum;
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(newcust);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }
        if (jCheckBox13.isSelected()==true)
        try {
            String newcust="cmd /c start /D \"%DROPBOX_HOME%\\SavannahScripts\\\" \" \" cpNdege.bat " + custname + " " + prognum;
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(newcust);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }
        

        if (jCheckBox16.isSelected()==true)
        try {
            String newcust="cmd /c start /D \"%DROPBOX_HOME%\\SavannahScripts\\\" \" \" cpBeachP.bat " + custname + " " + prognum;
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(newcust);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }

        if (jCheckBox17.isSelected()==true)
        try {
            String newcust="cmd /c start /D \"%DROPBOX_HOME%\\SavannahScripts\\\" \" \" cpBeach14.bat " + custname + " " + prognum;
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(newcust);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }

        if (machame.isSelected()==true)
        try {
            String newcust="cmd /c start /D \"%DROPBOX_HOME%\\SavannahScripts\\\" \" \" cpMachame.bat " + custname + " " + prognum;
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(newcust);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }

        if (Marangu7days.isSelected()==true)
        try {
            String newcust="cmd /c start /D \"%DROPBOX_HOME%\\SavannahScripts\\\" \" \" cpMarangu7days.bat " + custname + " " + prognum;
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(newcust);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }

        if (jCheckBox19.isSelected()==true)
        try {
            String newcust="cmd /c start /D \"%DROPBOX_HOME%\\SavannahScripts\\\" \" \" cpMarangu.bat " + custname + " " + prognum;
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(newcust);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }
        if (jCheckBox22.isSelected()==true)
        try {
            String newcust="cmd /c start /D \"%DROPBOX_HOME%\\SavannahScripts\\\" \" \" cpBeachZS.bat " + custname + " " + prognum;
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(newcust);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }

        if (jCheckBox24.isSelected()==true)
        try {
            String newcust="cmd /c start /D \"%DROPBOX_HOME%\\SavannahScripts\\\" \" \" cpBeachSimba.bat " + custname + " " + prognum;
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(newcust);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }
        if (jCheckBox25.isSelected()==true)
        try {
            String newcust="cmd /c start /D \"%DROPBOX_HOME%\\SavannahScripts\\\" \" \" cpRongai.bat " + custname + " " + prognum;
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(newcust);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }
        if (jCheckBox26.isSelected()==true)
        try {
            String newcust="cmd /c start /D \"%DROPBOX_HOME%\\SavannahScripts\\\" \" \" cpLemosho.bat " + custname + " " + prognum;
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(newcust);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }
        if (jCheckBox27.isSelected()==true)
        try {
            String newcust="cmd /c start /D \"%DROPBOX_HOME%\\SavannahScripts\\\" \" \" cpNyani.bat " + custname + " " + prognum;
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(newcust);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }
        if (jCheckBox28.isSelected()==true)
        try {
            String newcust="cmd /c start /D \"%DROPBOX_HOME%\\SavannahScripts\\\" \" \" cpBaobab.bat " + custname + " " + prognum;
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(newcust);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }
        
        if (DumaPemba.isSelected()==true)
        try {
            String newcust="cmd /c start /D \"%DROPBOX_HOME%\\SavannahScripts\\\" \" \" cpDumaPemba.bat " + custname + " " + prognum;
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(newcust);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }
        if (PumbaPemba.isSelected()==true)
        try {
            String newcust="cmd /c start /D \"%DROPBOX_HOME%\\SavannahScripts\\\" \" \" cpPumbaPemba.bat " + custname + " " + prognum;
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(newcust);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }
        if (SimbaPemba.isSelected()==true)
        try {
            String newcust="cmd /c start /D \"%DROPBOX_HOME%\\SavannahScripts\\\" \" \" cpSimbaPemba.bat " + custname + " " + prognum;
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(newcust);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }
        if (Simba2.isSelected()==true)
        try {
            String newcust="cmd /c start /D \"%DROPBOX_HOME%\\SavannahScripts\\\" \" \" cpSimba2.bat " + custname + " " + prognum;
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(newcust);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }
        if (Simba3.isSelected()==true)
        try {
            String newcust="cmd /c start /D \"%DROPBOX_HOME%\\SavannahScripts\\\" \" \" cpSimba3.bat " + custname + " " + prognum;
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(newcust);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }
        if (GranSafari.isSelected()==true)
        try {
            String newcust="cmd /c start /D \"%DROPBOX_HOME%\\SavannahScripts\\\" \" \" cpGS.bat " + custname + " " + prognum;
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(newcust);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }

        if (SundayGRP.isSelected()==true)
        try {
            String newcust="cmd /c start /D \"%DROPBOX_HOME%\\SavannahScripts\\\" \" \" cpSG.bat " + custname + " " + prognum;
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(newcust);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }

        if (ThursdayGRP.isSelected()==true)
        try {
            String newcust="cmd /c start /D \"%DROPBOX_HOME%\\SavannahScripts\\\" \" \" cpTG.bat " + custname + " " + prognum;
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(newcust);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }

        if (machame6.isSelected()==true)
        try {
            String newcust="cmd /c start /D \"%DROPBOX_HOME%\\SavannahScripts\\\" \" \" cpMachame6.bat " + custname + " " + prognum;
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(newcust);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }
        if (BeachDumaShort.isSelected()==true)
        try {
            String newcust="cmd /c start /D \"%DROPBOX_HOME%\\SavannahScripts\\\" \" \" cpbeachDS.bat " + custname + " " + prognum;
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(newcust);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }

        if (Lemosho10days.isSelected()==true)
        try {
            String newcust="cmd /c start /D \"%DROPBOX_HOME%\\SavannahScripts\\\" \" \" cpLemosho10days.bat " + custname + " " + prognum;
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(newcust);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }

        if (jLuxDuma.isSelected()==true)
        try {
            String newcust="cmd /c start /D \"%DROPBOX_HOME%\\SavannahScripts\\\" \" \" cpLuxDuma.bat " + custname + " " + prognum;
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(newcust);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }

        if (jLuxPumba.isSelected()==true)
        try {
            String newcust="cmd /c start /D \"%DROPBOX_HOME%\\SavannahScripts\\\" \" \" cpLuxPumba.bat " + custname + " " + prognum;
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(newcust);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }

        if (jLuxSimba.isSelected()==true)
        try {
            String newcust="cmd /c start /D \"%DROPBOX_HOME%\\SavannahScripts\\\" \" \" cpLuxSimba.bat " + custname + " " + prognum;
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(newcust);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }

        if (jDC.isSelected()==true)
        try {
            String newcust="cmd /c start /D \"%DROPBOX_HOME%\\SavannahScripts\\\" \" \" cpDC.bat " + custname + " " + prognum;
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(newcust);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }

        if (jPC.isSelected()==true)
        try {
            String newcust="cmd /c start /D \"%DROPBOX_HOME%\\SavannahScripts\\\" \" \" cpPC.bat " + custname + " " + prognum;
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(newcust);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }

        if (jSC.isSelected()==true)
        try {
            String newcust="cmd /c start /D \"%DROPBOX_HOME%\\SavannahScripts\\\" \" \" cpSC.bat " + custname + " " + prognum;
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(newcust);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }

        if (jKC.isSelected()==true)
        try {
            String newcust="cmd /c start /D \"%DROPBOX_HOME%\\SavannahScripts\\\" \" \" cpKC.bat " + custname + " " + prognum;
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(newcust);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }

        // Remove OPEN
        //try {
            //    String newcust="cmd /c start /D \"%DROPBOX_HOME%\\SavannahScripts\\\" \" \" remOPEN.bat " + custname;
            //    Runtime rn=Runtime.getRuntime();
            //    Process pr=rn.exec(newcust);
            //}   catch(IOException ioException) {
            //    System.out.println(ioException.getMessage() );
            //}
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jCheckBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        jTextField1.setText("");
        jTextField2.setText("NA");
        jTextField3.setText("NA");
        jTextField10.setText("NA");
        jTextField10b.setText("NA");
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed

        // open the folder in windows explorer
        try {
            // set customer name, i.e. folder
            String custnamein=jTextField1.getText();
            String custname=custnamein.replaceAll("\\s", "");;
            String newcust="cmd /c explorer.exe \"%DROPBOX_HOME%\\%REQ_YEAR%\\\"" + custname;
            System.out.println(newcust);
            Runtime rn=Runtime.getRuntime();
            Process pr=rn.exec(newcust);
        }   catch(IOException ioException) {
            System.out.println(ioException.getMessage() );
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        if (USE_API && AppSession.isLoggedIn()) {
            // New integrated flow: API creates folder in Dropbox + DB record
            NewRequestDialog dlg = new NewRequestDialog(this, AppSession.api);
            dlg.setVisible(true);
        } else {
            // Original fallback: run NewCust.bat locally
            try {
                String custnamein = jTextField1.getText();
                String custname   = custnamein.replaceAll("\\s", "");
                String newcust    = "cmd /c start /D \"%DROPBOX_HOME%\\SavannahScripts\\\" \" \" NewCust.bat " + custname;
                System.out.println(newcust);
                Runtime rn = Runtime.getRuntime();
                Process pr = rn.exec(newcust);
            } catch (IOException ioException) {
                System.out.println(ioException.getMessage());
            }
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed
        String mytext1 = jTextField11.getText();
        String mytext = mytext1.replaceAll("\\s", "");
        if (mytext.isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this,
                "Please enter a search term.", "Search",
                javax.swing.JOptionPane.WARNING_MESSAGE);
            return;
        }
        // /S = recursive, /b = bare (full path), searches 001_Safari and all subfolders
        String mycmd = "dir /S /b \"%DROPBOX_HOME%\\001_Safari\\\"*" + mytext + "*";
        java.util.List<String> results = runDirCommand(mycmd);
        showResultsPopup("Search results: " + mytext, results);
    }//GEN-LAST:event_jButton14ActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jCheckBox28ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox28ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox28ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BackOfficeMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BackOfficeMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BackOfficeMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BackOfficeMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BackOfficeMain().setVisible(true);
            }
        });
    }

    // -------------------------------------------------------------------------
    // Helper: popup Browse con ricerca, filtro real-time, navigazione e OK
    // -------------------------------------------------------------------------
    private void showBrowsePopup(String title, String rootPath) {
        final java.nio.file.Path rootDir = java.nio.file.Paths.get(rootPath);

        javax.swing.JDialog dialog = new javax.swing.JDialog(this, title, true);
        dialog.setSize(600, 540);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new java.awt.BorderLayout(4, 4));

        // --- Barra path + pulsante Indietro ---
        javax.swing.JTextField pathField = new javax.swing.JTextField(rootPath);
        pathField.setEditable(false);
        pathField.setFont(new java.awt.Font("Monospaced", java.awt.Font.PLAIN, 11));
        pathField.setBackground(new java.awt.Color(240, 240, 240));
        javax.swing.JButton backButton = new javax.swing.JButton("◀ Indietro");
        backButton.setPreferredSize(new java.awt.Dimension(100, 26));
        backButton.setEnabled(false);
        javax.swing.JPanel pathPanel = new javax.swing.JPanel(new java.awt.BorderLayout(4, 0));
        pathPanel.setBorder(javax.swing.BorderFactory.createEmptyBorder(6, 8, 0, 8));
        pathPanel.add(new javax.swing.JLabel("Path: "), java.awt.BorderLayout.WEST);
        pathPanel.add(pathField, java.awt.BorderLayout.CENTER);
        pathPanel.add(backButton, java.awt.BorderLayout.EAST);

        // --- Campo ricerca ---
        javax.swing.JTextField searchField = new javax.swing.JTextField();
        searchField.setFont(new java.awt.Font("SansSerif", java.awt.Font.PLAIN, 13));
        javax.swing.JPanel searchPanel = new javax.swing.JPanel(new java.awt.BorderLayout(6, 0));
        searchPanel.setBorder(javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8));
        searchPanel.add(new javax.swing.JLabel("Cerca:  "), java.awt.BorderLayout.WEST);
        searchPanel.add(searchField, java.awt.BorderLayout.CENTER);

        javax.swing.JPanel topPanel = new javax.swing.JPanel(new java.awt.BorderLayout());
        topPanel.add(pathPanel, java.awt.BorderLayout.NORTH);
        topPanel.add(searchPanel, java.awt.BorderLayout.SOUTH);

        // --- Lista ---
        javax.swing.DefaultListModel<String> model = new javax.swing.DefaultListModel<>();
        javax.swing.JList<String> list = new javax.swing.JList<>(model);
        list.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        list.setFont(new java.awt.Font("Monospaced", java.awt.Font.PLAIN, 13));
        javax.swing.JScrollPane scrollPane = new javax.swing.JScrollPane(list);
        scrollPane.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 8, 0, 8));

        // --- Pulsanti OK / Annulla ---
        javax.swing.JButton okButton = new javax.swing.JButton("OK");
        javax.swing.JButton cancelButton = new javax.swing.JButton("Annulla");
        okButton.setPreferredSize(new java.awt.Dimension(90, 28));
        cancelButton.setPreferredSize(new java.awt.Dimension(90, 28));
        javax.swing.JLabel hint = new javax.swing.JLabel(
            "  \uD83D\uDCC1 doppio click = entra nella cartella");
        hint.setFont(hint.getFont().deriveFont(java.awt.Font.ITALIC, 11f));
        javax.swing.JPanel bottomPanel = new javax.swing.JPanel(new java.awt.BorderLayout(6, 0));
        bottomPanel.setBorder(javax.swing.BorderFactory.createEmptyBorder(4, 8, 8, 8));
        javax.swing.JPanel btnPanel = new javax.swing.JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 8, 0));
        btnPanel.add(okButton);
        btnPanel.add(cancelButton);
        bottomPanel.add(hint, java.awt.BorderLayout.WEST);
        bottomPanel.add(btnPanel, java.awt.BorderLayout.EAST);

        dialog.add(topPanel,    java.awt.BorderLayout.NORTH);
        dialog.add(scrollPane,  java.awt.BorderLayout.CENTER);
        dialog.add(bottomPanel, java.awt.BorderLayout.SOUTH);

        // Stato navigazione
        final java.nio.file.Path[] currentDir = { rootDir };
        final String[][] allDisplayNames = { new String[0] };

        Runnable loadDir = () -> {
            searchField.setText("");
            java.io.File folder = currentDir[0].toFile();
            java.io.File[] files = folder.listFiles();
            if (files == null) files = new java.io.File[0];
            java.util.Arrays.sort(files, (a, b) -> {
                if (a.isDirectory() != b.isDirectory()) return a.isDirectory() ? -1 : 1;
                return a.getName().compareToIgnoreCase(b.getName());
            });
            allDisplayNames[0] = new String[files.length];
            for (int i = 0; i < files.length; i++)
                allDisplayNames[0][i] = (files[i].isDirectory() ? "\uD83D\uDCC1 " : "   ") + files[i].getName();
            javax.swing.DefaultListModel<String> nm = new javax.swing.DefaultListModel<>();
            for (String s : allDisplayNames[0]) nm.addElement(s);
            list.setModel(nm);
            pathField.setText(currentDir[0].toString());
            backButton.setEnabled(!currentDir[0].equals(rootDir));
            if (list.getModel().getSize() > 0) list.setSelectedIndex(0);
            searchField.requestFocusInWindow();
        };

        loadDir.run();

        // Filtro real-time
        searchField.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            private void filter() {
                String text = searchField.getText().toLowerCase();
                javax.swing.DefaultListModel<String> fm = new javax.swing.DefaultListModel<>();
                for (String s : allDisplayNames[0]) {
                    String name = s.startsWith("\uD83D\uDCC1 ") ? s.substring(3) : s.trim();
                    if (name.toLowerCase().contains(text)) fm.addElement(s);
                }
                list.setModel(fm);
                if (fm.getSize() > 0) list.setSelectedIndex(0);
            }
            public void insertUpdate(javax.swing.event.DocumentEvent e) { filter(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { filter(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) { filter(); }
        });

        // Selezione voce (helper)
        Runnable selectCurrent = () -> {
            String sel = list.getSelectedValue();
            if (sel == null && list.getModel().getSize() > 0)
                sel = list.getModel().getElementAt(0);
            if (sel == null) return;
            boolean isDir = sel.startsWith("\uD83D\uDCC1 ");
            String name = isDir ? sel.substring(3).trim() : sel.trim();
            if (isDir) {
                currentDir[0] = currentDir[0].resolve(name);
                loadDir.run();
            } else {
                jTextField1.setText(name);
                dialog.dispose();
            }
        };

        // Doppio click
        list.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                if (e.getClickCount() == 2) selectCurrent.run();
            }
        });

        // Pulsante OK — usa la selezione corrente senza navigare nelle cartelle
        okButton.addActionListener(e -> {
            String sel = list.getSelectedValue();
            if (sel == null) return;
            String name = sel.startsWith("\uD83D\uDCC1 ") ? sel.substring(3).trim() : sel.trim();
            jTextField1.setText(name);
            dialog.dispose();
        });

        // Pulsante Annulla
        cancelButton.addActionListener(e -> dialog.dispose());

        // Pulsante Indietro
        backButton.addActionListener(e -> {
            java.nio.file.Path parent = currentDir[0].getParent();
            if (parent != null && currentDir[0].startsWith(rootDir) && !currentDir[0].equals(rootDir)) {
                currentDir[0] = parent;
                loadDir.run();
            }
        });

        // Invio nel campo ricerca = doppio click sul primo risultato
        searchField.addActionListener(e -> selectCurrent.run());

        dialog.getRootPane().setDefaultButton(okButton);

        dialog.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override public void windowOpened(java.awt.event.WindowEvent e) {
                searchField.requestFocusInWindow();
            }
        });

        dialog.setVisible(true);
    }

    // -------------------------------------------------------------------------
    // Helper: ricerca ricorsiva per nome file/cartella in una directory
    // -------------------------------------------------------------------------
    private void searchRecursive(java.io.File folder, String keyword, java.util.List<String> results) {
        java.io.File[] files = folder.listFiles();
        if (files == null) return;
        for (java.io.File f : files) {
            if (f.getName().toLowerCase().contains(keyword)) {
                results.add(f.getAbsolutePath());
            }
            if (f.isDirectory()) {
                searchRecursive(f, keyword, results);
            }
        }
    }

    // -------------------------------------------------------------------------
    // Helper: esegue un comando dir e restituisce i risultati come lista
    // -------------------------------------------------------------------------
    private java.util.List<String> runDirCommand(String dirCmd) {
        java.util.List<String> results = new java.util.ArrayList<>();
        try {
            ProcessBuilder pb = new ProcessBuilder("cmd", "/c", dirCmd);
            pb.redirectErrorStream(true);
            Process pr = pb.start();
            java.io.BufferedReader reader = new java.io.BufferedReader(
                new java.io.InputStreamReader(pr.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty()) {
                    results.add(line);
                }
            }
            pr.waitFor();
        } catch (IOException | InterruptedException e) {
            System.out.println(e.getMessage());
        }
        return results;
    }

    // -------------------------------------------------------------------------
    // Helper: mostra i risultati in un popup; doppio click popola Customer File
    // -------------------------------------------------------------------------
    private void showResultsPopup(String title, java.util.List<String> results) {
        if (results.isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(
                this, "No results found.", title,
                javax.swing.JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        javax.swing.JDialog dialog = new javax.swing.JDialog(this, title, true);
        dialog.setSize(520, 380);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new java.awt.BorderLayout(0, 4));

        javax.swing.DefaultListModel<String> model = new javax.swing.DefaultListModel<>();
        for (String r : results) model.addElement(r);

        javax.swing.JList<String> list = new javax.swing.JList<>(model);
        list.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        list.setFont(new java.awt.Font("Monospaced", java.awt.Font.PLAIN, 13));

        list.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                if (e.getClickCount() == 2) {
                    String selected = list.getSelectedValue();
                    if (selected != null) {
                        String result;
                        java.io.File f = new java.io.File(selected);
                        if (f.isAbsolute()) {
                            // Full path (from dir /S /b): strip filename if it's a file
                            String folderPath = f.isDirectory() ? selected : f.getParent();
                            if (folderPath == null) folderPath = selected;
                            // Keep only the part after 001_Safari
                            String marker = "001_safari";
                            int idx = folderPath.toLowerCase().indexOf(marker);
                            if (idx >= 0) {
                                folderPath = folderPath.substring(idx + marker.length());
                                if (folderPath.startsWith("\\") || folderPath.startsWith("/")) {
                                    folderPath = folderPath.substring(1);
                                }
                            }
                            result = folderPath;
                        } else {
                            // Bare name (from dir /b): use directly
                            result = selected;
                        }
                        jTextField1.setText(result);
                        dialog.dispose();
                    }
                }
            }
        });

        javax.swing.JScrollPane scrollPane = new javax.swing.JScrollPane(list);
        scrollPane.setBorder(javax.swing.BorderFactory.createEmptyBorder(4, 6, 4, 6));

        javax.swing.JLabel hint = new javax.swing.JLabel(
            "  Double-click to select and populate Customer File");
        hint.setFont(hint.getFont().deriveFont(java.awt.Font.ITALIC, 11f));
        hint.setBorder(javax.swing.BorderFactory.createEmptyBorder(2, 6, 6, 6));

        dialog.add(scrollPane, java.awt.BorderLayout.CENTER);
        dialog.add(hint, java.awt.BorderLayout.SOUTH);
        dialog.setVisible(true);
    }

    // -------------------------------------------------------------------------
    /** Recursively apply fonts to all components in a container */
    private void applyFonts(java.awt.Container container, java.awt.Font base, java.awt.Font bold) {
        for (java.awt.Component c : container.getComponents()) {
            if (c instanceof javax.swing.JLabel)     c.setFont(base);
            if (c instanceof javax.swing.JCheckBox)  c.setFont(base);
            if (c instanceof javax.swing.JComboBox)  c.setFont(base);
            if (c instanceof javax.swing.JTextField) c.setFont(base);
            if (c instanceof javax.swing.JButton) {
                c.setFont(bold);
            }
            if (c instanceof java.awt.Container) applyFonts((java.awt.Container) c, base, bold);
        }
    }

    // -------------------------------------------------------------------------
    // Scans the customer's Dropbox folder for files whose names start with
    // a number, finds the maximum, and sets Prog Number to max+1.
    // Searches 2026/ first; if not found there, tries 001_Safari/.
    // Only updates the field if the user hasn't manually overridden it
    // (we never overwrite a value the user has explicitly typed — we only
    //  auto-fill when the field still shows its last auto-computed value).
    // -------------------------------------------------------------------------
    private int lastAutoProgNum = -1; // tracks the last value we auto-set

    private void autoScanProgNumber() {
        String folderName = jTextField1.getText().trim();
        if (folderName.isEmpty()) return;

        String dropboxHome = System.getenv("DROPBOX_HOME");
        String reqYear     = System.getenv("REQ_YEAR");
        if (dropboxHome == null) return;
        if (reqYear    == null) reqYear = "2026";

        // Try year folder first, then 001_Safari
        java.io.File folder = new java.io.File(dropboxHome + "\\" + reqYear + "\\" + folderName);
        if (!folder.exists() || !folder.isDirectory()) {
            folder = new java.io.File(dropboxHome + "\\001_Safari\\" + folderName);
        }
        if (!folder.exists() || !folder.isDirectory()) return;

        java.io.File[] files = folder.listFiles(java.io.File::isFile);
        int maxNum = 0;
        if (files != null) {
            for (java.io.File f : files) {
                java.util.regex.Matcher m =
                    java.util.regex.Pattern.compile("^(\\d+)").matcher(f.getName());
                if (m.find()) {
                    try {
                        int n = Integer.parseInt(m.group(1));
                        if (n > maxNum) maxNum = n;
                    } catch (NumberFormatException ignored) {}
                }
            }
        }

        final int nextNum = maxNum + 1; // 1 if no numbered files found

        // Only update if the current value equals the last auto-set value
        // (i.e. user hasn't manually changed it)
        javax.swing.SwingUtilities.invokeLater(() -> {
            String current = jTextField4.getText().trim();
            boolean userOverrode;
            try {
                userOverrode = (lastAutoProgNum >= 0 && Integer.parseInt(current) != lastAutoProgNum);
            } catch (NumberFormatException ex) {
                userOverrode = true; // non-numeric = user typed something custom
            }
            if (!userOverrode || lastAutoProgNum < 0) {
                jTextField4.setText(String.format("%02d", nextNum));
                lastAutoProgNum = nextNum;
            }
        });
    }

    // -------------------------------------------------------------------------
    // Direct HTTP POST to a leads-module API endpoint with a 30-second timeout.
    // Derives the URL from LEADS_LOOKUP_URL (replaces "lookup.php").
    // Returns the raw response body as a String.
    // -------------------------------------------------------------------------
    private static String postApiDirect(String endpoint, String jsonBody) throws Exception {
        // Build URL: strip "lookup.php" from the end and append endpoint
        String base = LEADS_LOOKUP_URL;
        int lastSlash = base.lastIndexOf('/');
        String endpointUrl = (lastSlash >= 0 ? base.substring(0, lastSlash + 1) : base + "/") + endpoint;

        java.net.URL url = new java.net.URL(endpointUrl);
        java.net.HttpURLConnection conn = (java.net.HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setConnectTimeout(15_000);   // 15 s connect
        conn.setReadTimeout(30_000);      // 30 s read
        conn.setDoOutput(true);
        conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        conn.setRequestProperty("X-API-Key", API_KEY_VALUE);

        byte[] payload = jsonBody.getBytes(java.nio.charset.StandardCharsets.UTF_8);
        conn.setRequestProperty("Content-Length", String.valueOf(payload.length));
        try (java.io.OutputStream os = conn.getOutputStream()) {
            os.write(payload);
        }

        int code = conn.getResponseCode();
        java.io.InputStream is = (code >= 200 && code < 300)
                ? conn.getInputStream() : conn.getErrorStream();
        if (is == null) return "(HTTP " + code + " — no body)";
        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(is, java.nio.charset.StandardCharsets.UTF_8))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            return sb.toString();
        } finally {
            conn.disconnect();
        }
    }

    // -------------------------------------------------------------------------
    // Displays script output (or any message) in a compact scrollable popup.
    // isError=true → red title, ERROR icon; false → INFO icon.
    // -------------------------------------------------------------------------
    private void showScriptOutputPopup(String title, String message, boolean isError) {
        if (message == null) message = "(no output)";
        javax.swing.JTextArea ta = new javax.swing.JTextArea(message.trim());
        ta.setEditable(false);
        ta.setFont(new java.awt.Font("Monospaced", java.awt.Font.PLAIN, 12));
        ta.setLineWrap(true);
        ta.setWrapStyleWord(true);
        ta.setBackground(new java.awt.Color(245, 245, 245));
        ta.setBorder(javax.swing.BorderFactory.createEmptyBorder(6, 8, 6, 8));
        javax.swing.JScrollPane sp = new javax.swing.JScrollPane(ta);
        sp.setPreferredSize(new java.awt.Dimension(460, 160));
        sp.setBorder(null);
        int msgType = isError ? JOptionPane.ERROR_MESSAGE : JOptionPane.INFORMATION_MESSAGE;
        JOptionPane.showMessageDialog(this, sp, title, msgType);
    }

    // -------------------------------------------------------------------------
    // Help dialog — User Guide
    // -------------------------------------------------------------------------
    private void showHelpDialog() {
        String[] sections = {
            "CUSTOMER REQUEST (top field)",
            "  Type or select the Dropbox folder name for the customer.\n"
          + "  Used as the key for all operations below.",

            "NEW REQUEST button",
            "  Opens the New Request dialog.\n"
          + "  Creates a Dropbox folder + DB record.\n"
          + "  After creation, the folder name is copied into Customer Request.",

            "CONFIRM SAFARI button",
            "  Renames the folder in the year directory (2026) to include\n"
          + "  travel dates and status, then moves it into 001_Safari.\n"
          + "  Required fields: Start Date (DDMMM), End Date (DDMMMYYYY),\n"
          + "  Middle Date (DDMMM or NA). When connected to the hub,\n"
          + "  the DB status is set to Booked and the booking date is saved.",

            "COPY PROGRAMS button",
            "  Copies the selected program templates (Duma, Pumba, etc.)\n"
          + "  into the customer's Dropbox folder.\n"
          + "  Customer Request and Prog Number must be filled.",

            "RENAME (Dropbox Folder section)",
            "  Renames a folder inside the selected year/sub-folder.\n"
          + "  Current name = name to rename FROM.\n"
          + "  New name = name to rename TO.\n"
          + "  Status tags (PROGRESS, DEPOSIT, etc.) are managed automatically.\n"
          + "  'Copy To Customer File' puts the new name into Customer Request.",

            "SEARCH 2026 / 001_Safari buttons",
            "  Searches for matching folder names in the respective directory.\n"
          + "  Double-click a result to populate Customer Request.",

            "LOOKUP LEADS (menu)",
            "  Opens the hub Leads lookup page in your browser,\n"
          + "  pre-filled with the current Customer Request text.",

            "DATE FORMATS",
            "  Start/Middle Date : DDMMM        e.g.  05JAN\n"
          + "  End Date          : DDMMMYYYY    e.g.  18JAN2026",

            "CONFIGURATION",
            "  File: config.properties (same folder as the app JAR)\n"
          + "  use.api=true/false   — enable hub API integration\n"
          + "  api.base_url=...     — hub base URL\n"
          + "  api.key=...          — shared API key"
        };

        javax.swing.JPanel panel = new javax.swing.JPanel();
        panel.setLayout(new javax.swing.BoxLayout(panel, javax.swing.BoxLayout.Y_AXIS));
        panel.setBorder(javax.swing.BorderFactory.createEmptyBorder(8, 4, 8, 4));

        for (int i = 0; i < sections.length; i += 2) {
            // Section header
            javax.swing.JLabel header = new javax.swing.JLabel(sections[i]);
            header.setFont(new java.awt.Font("SansSerif", java.awt.Font.BOLD, 12));
            header.setForeground(new java.awt.Color(160, 26, 20));
            header.setBorder(javax.swing.BorderFactory.createEmptyBorder(
                i == 0 ? 0 : 10, 0, 2, 0));
            header.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);
            panel.add(header);
            // Section body
            javax.swing.JTextArea body = new javax.swing.JTextArea(sections[i + 1]);
            body.setEditable(false);
            body.setFont(new java.awt.Font("SansSerif", java.awt.Font.PLAIN, 12));
            body.setBackground(panel.getBackground());
            body.setLineWrap(true);
            body.setWrapStyleWord(true);
            body.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);
            body.setMaximumSize(new java.awt.Dimension(540, 200));
            panel.add(body);
        }

        javax.swing.JScrollPane sp = new javax.swing.JScrollPane(panel);
        sp.setPreferredSize(new java.awt.Dimension(580, 480));
        sp.getVerticalScrollBar().setUnitIncrement(12);
        sp.setBorder(null);

        javax.swing.JDialog dlg = new javax.swing.JDialog(this, "Help — User Guide", true);
        dlg.setLayout(new java.awt.BorderLayout());
        dlg.add(sp, java.awt.BorderLayout.CENTER);
        javax.swing.JButton close = new javax.swing.JButton("Close");
        close.addActionListener(e -> dlg.dispose());
        javax.swing.JPanel bottom = new javax.swing.JPanel(
            new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT));
        bottom.add(close);
        dlg.add(bottom, java.awt.BorderLayout.SOUTH);
        dlg.setSize(620, 560);
        dlg.setLocationRelativeTo(this);
        dlg.setVisible(true);
    }

    // -------------------------------------------------------------------------
    // Opens the Leads lookup page in the system browser, pre-filled with the
    // current Customer Request string from jTextField1.
    // -------------------------------------------------------------------------
    private void lookupLeadsInBrowser() {
        String query = jTextField1.getText().trim();
        try {
            String url;
            if (query.isEmpty()) {
                // No customer request typed — open the bare lookup page
                url = LEADS_LOOKUP_URL;
            } else {
                String encoded = URLEncoder.encode(query, "UTF-8");
                url = LEADS_LOOKUP_URL + "?q=" + encoded;
            }
            Desktop.getDesktop().browse(new URI(url));
        } catch (Exception ex) {
            javax.swing.JOptionPane.showMessageDialog(this,
                "Could not open browser:\n" + ex.getMessage(),
                "Lookup Leads", javax.swing.JOptionPane.ERROR_MESSAGE);
        }
    }

    // Load config.properties — returns true if API is enabled and configured.
    // -------------------------------------------------------------------------
    private boolean loadConfig() {
        Properties props = new Properties();
        try (FileInputStream fis = new FileInputStream(CONFIG_FILE)) {
            props.load(fis);
        } catch (java.io.IOException e) {
            System.out.println("config.properties not found — running without API (" + e.getMessage() + ")");
            return false;
        }
        boolean useApi = "true".equalsIgnoreCase(props.getProperty("use.api", "false"));
        if (!useApi) return false;

        String baseUrl = props.getProperty("api.base_url", "").trim();
        String apiKey  = props.getProperty("api.key",      "").trim();
        if (baseUrl.isEmpty()) {
            System.out.println("config.properties: api.base_url not set — API disabled");
            return false;
        }
        AppSession.api = new ApiClient(baseUrl, apiKey);
        API_KEY_VALUE = apiKey;
        // Derive the Leads lookup URL using only scheme+host from baseUrl,
        // so it works regardless of whether baseUrl already includes a sub-path.
        try {
            java.net.URL parsed = new java.net.URL(baseUrl);
            LEADS_LOOKUP_URL = parsed.getProtocol() + "://" + parsed.getHost()
                               + "/modules/leads/lookup.php";
        } catch (Exception ignored) {
            // keep the hardcoded default
        }
        return true;
    }

    // -------------------------------------------------------------------------
    // Called by NewRequestDialog on success to populate the Customer File field.
    // -------------------------------------------------------------------------
    public void setCustomerFile(String folderName) {
        jTextField1.setText(folderName);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox BeachDumaShort;
    private javax.swing.JCheckBox DumaPemba;
    private javax.swing.JCheckBox GranSafari;
    private javax.swing.JCheckBox Lemosho10days;
    private javax.swing.JCheckBox Marangu7days;
    private javax.swing.JCheckBox PumbaPemba;
    private javax.swing.JCheckBox Simba2;
    private javax.swing.JCheckBox Simba3;
    private javax.swing.JCheckBox SimbaPemba;
    private javax.swing.JCheckBox SundayGRP;
    private javax.swing.JCheckBox ThursdayGRP;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton17;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JComboBox<String> jComboBoxFrom;
    private javax.swing.JComboBox<String> jComboBoxTo;
    private javax.swing.JButton jButtonRename;
    private javax.swing.JButton jButtonClearRename;
    private javax.swing.JButton jButtonToCustomerFile;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JCheckBox jCheckBox11;
    private javax.swing.JCheckBox jCheckBox12;
    private javax.swing.JCheckBox jCheckBox13;
    private javax.swing.JCheckBox jCheckBox16;
    private javax.swing.JCheckBox jCheckBox17;
    private javax.swing.JCheckBox jCheckBox19;
    private javax.swing.JCheckBox jCheckBox2;
    private javax.swing.JCheckBox jCheckBox22;
    private javax.swing.JCheckBox jCheckBox24;
    private javax.swing.JCheckBox jCheckBox25;
    private javax.swing.JCheckBox jCheckBox26;
    private javax.swing.JCheckBox jCheckBox27;
    private javax.swing.JCheckBox jCheckBox28;
    private javax.swing.JCheckBox jCheckBox3;
    private javax.swing.JCheckBox jCheckBox4;
    private javax.swing.JCheckBox jCheckBox5;
    private javax.swing.JCheckBox jCheckBox6;
    private javax.swing.JCheckBox jCheckBox7;
    private javax.swing.JCheckBox jCheckBox8;
    private javax.swing.JCheckBox jCheckBox9;
    private javax.swing.JCheckBox jDC;
    private javax.swing.JCheckBox jDumaShort;
    private javax.swing.JCheckBox jKC;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JCheckBox jLuxDuma;
    private javax.swing.JCheckBox jLuxPumba;
    private javax.swing.JCheckBox jLuxSimba;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem13;
    private javax.swing.JMenuItem jMenuItem16;
    private javax.swing.JMenuItem jMenuItem17;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenuItem jMenuItem4;
    private javax.swing.JMenuItem jMenuItem6;
    private javax.swing.JCheckBox jPC;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JRadioButtonMenuItem jRadioButtonMenuItem1;
    private javax.swing.JCheckBox jSC;
    private javax.swing.JScrollBar jScrollBar2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton jSearch;
    private javax.swing.JButton jSearchSafari;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField10;
    private javax.swing.JTextField jTextField10b;
    private javax.swing.JLabel jLabel7b;
    private javax.swing.JTextField jTextField11;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JComboBox<String> jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    private javax.swing.JCheckBox machame;
    private javax.swing.JCheckBox machame6;
    // End of variables declaration//GEN-END:variables
}
